var searchData=
[
  ['ignoreaspectratio',['IgnoreAspectRatio',['../class_w_size.html#a822a80ee8ee94df9fa62b952a3026082a702bdbac8c5ea7ed1d95beeb10c3310a',1,'WSize']]],
  ['invalid',['Invalid',['../class_w_color.html#a9d55d2cb29a46b1b2abc4653effc993cacd0b7d7637003f728d55f1b37c2177c5',1,'WColor']]]
];
