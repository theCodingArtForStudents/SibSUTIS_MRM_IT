var searchData=
[
  ['green',['green',['../class_w_color.html#a54e6a8436a0b30cadca731e512acf493',1,'WColor']]]
];
