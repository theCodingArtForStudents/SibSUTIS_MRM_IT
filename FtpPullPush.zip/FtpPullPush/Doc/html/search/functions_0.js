var searchData=
[
  ['_5f_5faddupdatelistener',['__addUpdateListener',['../class_w_abstract_item_model.html#a65f1e93456394b594f8673f0c3b89330',1,'WAbstractItemModel']]],
  ['_5f_5fremoveupdatelistener',['__removeUpdateListener',['../class_w_abstract_item_model.html#a1bd5dc835aeae91d7c8db5ec9bf9a746',1,'WAbstractItemModel']]]
];
