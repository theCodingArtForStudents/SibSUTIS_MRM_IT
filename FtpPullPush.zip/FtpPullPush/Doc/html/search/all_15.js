var searchData=
[
  ['value',['value',['../class_w_color.html#ae1fdf0c09687a1db07bfd300875d268c',1,'WColor::value()'],['../class_w_line_edit.html#acd17134ec9f7ef379aab5cb05ceb24c1',1,'WLineEdit::value()'],['../class_w_progress_bar.html#a1b47a836e306212004e54ccb7c28e936',1,'WProgressBar::value()'],['../class_w_spin_box.html#a334b4e9ae9a470fab2afeb506824c691',1,'WSpinBox::value()']]]
];
