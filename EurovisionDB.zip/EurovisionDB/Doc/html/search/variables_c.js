var searchData=
[
  ['saturation',['saturation',['../class_w_color.html#a2098030fa75aafcc387cf78a5ba768ef',1,'WColor']]],
  ['subscribers',['subscribers',['../class_w_line_edit.html#a3c135c40b59a0ff9cecd0f7969766b77',1,'WLineEdit']]]
];
