var searchData=
[
  ['aspectratiomode',['AspectRatioMode',['../class_w_size.html#a822a80ee8ee94df9fa62b952a3026082',1,'WSize']]]
];
