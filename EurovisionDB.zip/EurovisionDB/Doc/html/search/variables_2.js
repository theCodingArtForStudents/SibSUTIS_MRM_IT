var searchData=
[
  ['black',['black',['../class_w_color.html#a6bd4a540d9fa2aef321cbfcafc5ef64b',1,'WColor']]],
  ['blue',['blue',['../class_w_color.html#a9fce56b44ace4ce1345a91b0984bfcc8',1,'WColor']]]
];
