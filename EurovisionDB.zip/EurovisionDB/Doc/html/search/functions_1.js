var searchData=
[
  ['accept',['accept',['../class_w_event.html#a5617342f80cadeb3df01840df098d484',1,'WEvent']]],
  ['addbutton',['addButton',['../class_w_button_group.html#af6e3b62598ad6dd2d4b34aaa468ce79e',1,'WButtonGroup']]],
  ['addcomponent',['addComponent',['../class_w_application.html#a30e6c9531a620eb113b4fbd3e84b496a',1,'WApplication']]],
  ['addcountries',['addCountries',['../class_countries_table.html#a96ad2cd397824d6e7f8963613f26ac76',1,'CountriesTable::addCountries(int id, CountryInfo info)'],['../class_countries_table.html#a364850524b652a81e75b8c4160d7f4d9',1,'CountriesTable::addCountries(int id, int idArtist, WString title)']]],
  ['addlistitem',['addListItem',['../class_w_list_box.html#a4fd2402896dd01e51051fdc7941a4584',1,'WListBox']]],
  ['addrow',['addRow',['../class_artists_table.html#a33e18189b71d88864687bc549e3bb327',1,'ArtistsTable::addRow(int id, FullName fullName)'],['../class_artists_table.html#abbb1a26a86b9692b95cdbd1125341371',1,'ArtistsTable::addRow(int id, WString name, WString surname)']]],
  ['addsong',['addSong',['../class_song_table.html#afbd9e7a6d066fc3f4597b6cc1a99b1e3',1,'SongTable::addSong(int id, SongInfo info)'],['../class_song_table.html#a2df0d1a02672c1838f5cb6ea970dfb7c',1,'SongTable::addSong(int id, int idArtist, WString title)']]],
  ['applicationname',['applicationName',['../class_w_application.html#a6a9992cb7833b6e55f69571a82ae526f',1,'WApplication']]],
  ['applicationversion',['applicationVersion',['../class_w_application.html#ad2bcf6183f06b013525956503fc20e14',1,'WApplication']]],
  ['artiststable',['ArtistsTable',['../class_artists_table.html#add01aaea4bcc71551b6ac4d7657cbc06',1,'ArtistsTable']]]
];
