var searchData=
[
  ['yellow',['yellow',['../class_w_color.html#a6cb3c7f323a7482b7ce84c6a0a9861b2',1,'WColor']]]
];
