var searchData=
[
  ['artists',['Artists',['../artiststable_8h.html#a965717a0fedcf85674144701821b4b2c',1,'artiststable.h']]]
];
