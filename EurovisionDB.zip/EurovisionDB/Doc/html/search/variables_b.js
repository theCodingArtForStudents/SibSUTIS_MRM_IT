var searchData=
[
  ['red',['red',['../class_w_color.html#a05a6d55e12c4367190ade6f3e09e74e2',1,'WColor']]],
  ['row',['row',['../struct_w_model_index.html#ababb37c31200487a27578dde6f6a7535',1,'WModelIndex']]]
];
