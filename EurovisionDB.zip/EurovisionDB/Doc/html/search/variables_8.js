var searchData=
[
  ['lightness',['lightness',['../class_w_color.html#a5d2aeca12ffed36c9d5d88883fb69bc2',1,'WColor']]]
];
