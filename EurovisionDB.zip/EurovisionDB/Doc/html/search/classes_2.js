var searchData=
[
  ['fullname',['FullName',['../struct_full_name.html',1,'']]]
];
