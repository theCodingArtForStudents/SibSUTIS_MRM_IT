var searchData=
[
  ['value',['value',['../class_w_color.html#ae1fdf0c09687a1db07bfd300875d268c',1,'WColor']]]
];
