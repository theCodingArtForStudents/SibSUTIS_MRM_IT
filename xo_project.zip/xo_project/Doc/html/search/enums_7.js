var searchData=
[
  ['type',['Type',['../class_w_event.html#ad334c0c66468637f15ba0fb6d50617bf',1,'WEvent']]]
];
