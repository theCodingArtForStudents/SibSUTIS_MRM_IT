var searchData=
[
  ['playertype',['PlayerType',['../xogame_8h.html#abe590f3c9109f404f003d5d7e4f0fccf',1,'xogame.h']]]
];
