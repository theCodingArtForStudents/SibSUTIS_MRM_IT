var searchData=
[
  ['backbutton',['BackButton',['../class_w_mouse_event.html#a6dccad9678fa9d29d66a04e890ebb27dad41e7ec588cf3d1f5162857799dcb0a1',1,'WMouseEvent']]],
  ['botjustify',['BotJustify',['../wshape_8h.html#a471e4dee996283178774f8de058533e0a451eb58eb045fadb0c3fb36e6e188364',1,'wshape.h']]]
];
