var searchData=
[
  ['spec',['Spec',['../class_w_color.html#a9d55d2cb29a46b1b2abc4653effc993c',1,'WColor']]],
  ['standardlocation',['StandardLocation',['../class_w_standard_paths.html#a3c2f1fd6318e3ad8d3c44458d832984f',1,'WStandardPaths']]]
];
