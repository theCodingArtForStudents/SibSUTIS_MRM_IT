var searchData=
[
  ['aimove',['AiMove',['../struct_ai_move.html',1,'']]]
];
