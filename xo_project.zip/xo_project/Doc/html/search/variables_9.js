var searchData=
[
  ['magenta',['magenta',['../class_w_color.html#a1cf8feaa45f134cc758421930ccc4991',1,'WColor']]]
];
